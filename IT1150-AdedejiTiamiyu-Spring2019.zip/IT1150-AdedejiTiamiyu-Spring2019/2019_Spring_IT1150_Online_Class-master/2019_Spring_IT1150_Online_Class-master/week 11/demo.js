//Javascript is case sensitive

/*Javascript statement end in a semicolon
Javascript comments can span single or multiple lines*/


console.log("console log - hello world");//log in developer tools
var globalX = 100;//global scope

function hello() //function definition
{
    alert("alert - hello world!");//popup window    
}

function add()//function definition
{
    var x = 3;
    var y = 5;
    var sum = x + y;
    alert("Sum is " + sum);
}

function substract()
{
    var a = 1000;
    var b = 100;
    var diff = a - b;
    alert("Difference is" + diff);
}

//Homework Lab- Complete Multiplication and Division functionality

function increment()
{ 
    var y = 10;//local scope - resets y everytime function is called
    globalX = globalX+10;//can add any number to itself
    //y = y+10;
    y+=10;//same as y = y+10;
    alert("x="+globalX + "y="+y); 

}

/* JS statements
Conditional statements:
If statement
Switch statement

Loops:
For loop
While loop
Do while loop

Break
*/

function compare()
{
    var charlie = 120;
    var john = 120;
    
    //conditional if statement
    
    if (charlie > john)
    {
        alert("Charlie is taller");
    }
    else if( charlie == john)//"=" is assignment; "==" is comparison
    {
        alert("Charlie and John are of the same height");
    }
    else
    {
        alert("John is taller");
    }

}

function IsTropical(fruit)//fruit is a variable and is an input parameter
{
    
    var isTropical = false; //boolean variable: True or False

    switch(fruit)
    {
        case "banana":
            isTropical = true;
            break;

        case "papaya":
            isTropical = true;
            break;

        case "tomato":
            isTropical = false;
            break;

        case "mango":
            isTropical = true;
            break;

        case "watermelon":
            isTropical = true;
            break;

        default:
            isTropical = false;            
    }

    alert("Is "+ fruit+ " tropical?"+ isTropical );

}

function Repeat( message )
{
    var counter = 0;
    console.log("While loop:");
    while (counter < 5)
    {
        console.log( message );
        counter++; //You have to remember to increment the counter otherwise the loop will go on endlessly
    }

    counter = 0;
    console.log("Do - While loop:");
    do 
    {
        console.log( message );
        counter++; //You have to remember to increment the counter otherwise the loop will go on endlessly
    } while (counter < 5);

    console.log("For loop:");
    /************************************************* */
    for(var counter=0; counter < 5; counter++)
    {
        console.log(message);
    }
}

function multiplication()//function definition
{
    var d = 25;
    var y = 42;
    var multiply = d * y;
    alert("25*42 = 1050");
}

function Division()//function definition
{
    var x = 48;
    var y = 12;
    var divide = x / y;
    alert("48/12 = 4");
}

function mean()//mean is the average of all the data in a set
{
    var mean = // add all the numbers 25+47+98+46+52=268 then divide it by the number of data point 268/5=53.6
    alert("mean = 53.6");
}

function evennumber()// evennumbers are numbers that can be divided by 2
{
    var evennumber = // evennumber = [munber of terms 100*(first term 2 + 200 last term)]/2 = 10100
    alert("sum of evennumber betwenn 2-200 = 10100");
} 

function fibonacci() // 1,1,2,3,5,8,13,21
{
    var fibonacci = // first 2 numbers are fixed 1,1. the 3rd nmber is the sum of the first and second number (1+1=2). The 4th number is the sum of the second and third (2+1=3) and so on
    alert("the first 20 numbers of a fibonacci is 1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584,4181,6765")
}