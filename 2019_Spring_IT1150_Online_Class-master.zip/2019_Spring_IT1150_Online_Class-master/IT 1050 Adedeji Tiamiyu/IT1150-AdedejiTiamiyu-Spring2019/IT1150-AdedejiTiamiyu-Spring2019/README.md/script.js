function sayHelloJS()

document.getElementById("js").innerHTML ="Hello from JavaScript!"